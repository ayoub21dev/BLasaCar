#!/usr/bin/env bash
set -euo pipefail

# Run this inside the Ubuntu VM.
# It installs a real Laravel lab stack:
# Nginx -> PHP-FPM -> Laravel in /var/www/lab-laravel.

APP_DIR="${APP_DIR:-/var/www/lab-laravel}"
APP_NAME="${APP_NAME:-LaravelLab}"
APP_URL="${APP_URL:-http://localhost}"
LINUX_USER="$(id -un)"
LOG_FILE="/tmp/laravel-lab-install.log"

export DEBIAN_FRONTEND=noninteractive
export NEEDRESTART_MODE=a

exec > >(tee "$LOG_FILE") 2>&1

echo "== Laravel lab install started =="
echo "User: $LINUX_USER"
echo "App dir: $APP_DIR"
echo "App URL: $APP_URL"

sudo -v

sudo apt-get update
sudo apt-get install -y \
  ca-certificates curl unzip git nginx sqlite3 composer \
  php-cli php-fpm php-mbstring php-xml php-curl php-zip \
  php-sqlite3 php-bcmath php-tokenizer php-mysql

PHPVER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;')"
sudo systemctl enable --now nginx "php${PHPVER}-fpm"
sudo systemctl restart "php${PHPVER}-fpm"

sudo install -d -o "$LINUX_USER" -g www-data /var/www

if [ -d "$APP_DIR" ]; then
  BACKUP_DIR="${APP_DIR}.backup.$(date +%Y%m%d%H%M%S)"
  echo "Existing app found. Moving it to $BACKUP_DIR"
  sudo mv "$APP_DIR" "$BACKUP_DIR"
fi

cd /var/www
if php -r 'exit(PHP_VERSION_ID >= 80200 ? 0 : 1);'; then
  composer create-project laravel/laravel "$(basename "$APP_DIR")" --no-interaction --prefer-dist
else
  composer create-project laravel/laravel "$(basename "$APP_DIR")" "^10.0" --no-interaction --prefer-dist
fi

cd "$APP_DIR"
cp -n .env.example .env
touch database/database.sqlite

set_env() {
  local key="$1"
  local value="$2"

  if grep -q "^${key}=" .env; then
    sed -i "s|^${key}=.*|${key}=${value}|" .env
  else
    printf '%s=%s\n' "$key" "$value" >> .env
  fi
}

set_env APP_NAME "$APP_NAME"
set_env APP_ENV local
set_env APP_DEBUG true
set_env APP_URL "$APP_URL"
set_env DB_CONNECTION sqlite
set_env DB_DATABASE "$APP_DIR/database/database.sqlite"

php artisan key:generate --force
php artisan migrate --force
php artisan optimize:clear

sudo chown -R "$LINUX_USER:www-data" "$APP_DIR"
sudo chmod -R ug+rwX "$APP_DIR/storage" "$APP_DIR/bootstrap/cache" "$APP_DIR/database"

PHP_FPM_SOCK="$(find /run/php -maxdepth 1 -type s -name 'php*-fpm.sock' | sort | tail -n 1)"
if [ -z "$PHP_FPM_SOCK" ]; then
  echo "ERROR: No PHP-FPM socket found in /run/php"
  exit 1
fi

sudo tee /etc/nginx/sites-available/lab-laravel >/dev/null <<'NGINX'
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    root __APP_DIR__/public;
    index index.php index.html;

    add_header X-Frame-Options "SAMEORIGIN";
    add_header X-Content-Type-Options "nosniff";

    charset utf-8;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location = /favicon.ico { access_log off; log_not_found off; }
    location = /robots.txt  { access_log off; log_not_found off; }

    error_page 404 /index.php;

    location ~ \.php$ {
        fastcgi_pass unix:__PHP_FPM_SOCK__;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    location ~ /\.(?!well-known).* {
        deny all;
    }
}
NGINX

sudo sed -i "s|__APP_DIR__|$APP_DIR|g; s|__PHP_FPM_SOCK__|$PHP_FPM_SOCK|g" /etc/nginx/sites-available/lab-laravel
sudo rm -f /etc/nginx/sites-enabled/default
sudo ln -sf /etc/nginx/sites-available/lab-laravel /etc/nginx/sites-enabled/lab-laravel
sudo nginx -t
sudo systemctl reload nginx

curl -fsS -I http://127.0.0.1 | head -n 1

echo
echo "DONE"
echo "Laravel app path: $APP_DIR"
echo "Install log: $LOG_FILE"
echo "Open inside Ubuntu: http://localhost"
echo "Now run 02-windows-share-virtualbox-laravel.ps1 on Windows as Administrator."
