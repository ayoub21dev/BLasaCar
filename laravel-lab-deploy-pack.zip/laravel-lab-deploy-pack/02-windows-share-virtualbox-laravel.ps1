param(
    [string]$VmName = "",
    [int]$HostPort = 8088,
    [int]$GuestPort = 80,
    [int]$SharePort = 8080,
    [switch]$NoStartVm,
    [switch]$SkipVirtualBox
)

# Run this on the Windows host as Administrator.
# It configures:
# - VirtualBox NAT: Windows localhost:$HostPort -> Ubuntu:$GuestPort
# - Windows firewall rules
# - Windows portproxy: all interfaces:$SharePort -> localhost:$HostPort
# Then it prints working URLs.

$ErrorActionPreference = "Stop"

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdmin)) {
    if (-not $PSCommandPath) {
        throw "Run this script from a saved .ps1 file in PowerShell as Administrator."
    }

    $argsText = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`" -HostPort $HostPort -GuestPort $GuestPort -SharePort $SharePort"
    if ($VmName) { $argsText += " -VmName `"$VmName`"" }
    if ($NoStartVm) { $argsText += " -NoStartVm" }
    if ($SkipVirtualBox) { $argsText += " -SkipVirtualBox" }

    Start-Process -FilePath "powershell.exe" -ArgumentList $argsText -Verb RunAs
    exit
}

function Find-VBoxManage {
    $candidates = @(
        "$env:ProgramFiles\Oracle\VirtualBox\VBoxManage.exe",
        "${env:ProgramFiles(x86)}\Oracle\VirtualBox\VBoxManage.exe"
    )

    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path $candidate)) {
            return $candidate
        }
    }

    $cmd = Get-Command VBoxManage.exe -ErrorAction SilentlyContinue
    if ($cmd) {
        return $cmd.Source
    }

    throw "VBoxManage.exe was not found. Install VirtualBox first."
}

function Run-VBox {
    param(
        [string[]]$VBoxArgs,
        [switch]$AllowFail
    )

    $output = & $script:VBoxManage @VBoxArgs 2>&1
    if ($LASTEXITCODE -ne 0 -and -not $AllowFail) {
        $output | ForEach-Object { Write-Host $_ }
        throw "VBoxManage failed: $($VBoxArgs -join ' ')"
    }

    return $output
}

function Add-AllowRule {
    param(
        [string]$Name,
        [int]$Port
    )

    & netsh advfirewall firewall delete rule name="$Name" | Out-Null
    & netsh advfirewall firewall add rule name="$Name" dir=in action=allow protocol=TCP localport=$Port profile=any edge=yes | Out-Null
}

if (-not $SkipVirtualBox) {
    $script:VBoxManage = Find-VBoxManage
    Write-Host "VBoxManage: $script:VBoxManage"

    $vmLines = Run-VBox @("list", "vms")
    $vmNames = @()
    foreach ($line in $vmLines) {
        if ($line -match '^"(.+)"\s+\{') {
            $vmNames += $Matches[1]
        }
    }

    if (-not $VmName) {
        if ($vmNames.Count -eq 1) {
            $VmName = $vmNames[0]
        } else {
            Write-Host "Choose a VM name and rerun with -VmName `"NAME`". Available VMs:"
            $vmNames | ForEach-Object { Write-Host " - $_" }
            exit 1
        }
    }

    Write-Host "Using VM: $VmName"
    $info = Run-VBox @("showvminfo", $VmName, "--machinereadable")
    $stateLine = $info | Where-Object { $_ -match '^VMState=' } | Select-Object -First 1
    $state = ($stateLine -replace '^VMState="(.+)"$', '$1')
    Write-Host "VM state: $state"

    if ($state -eq "running") {
        Run-VBox @("controlvm", $VmName, "natpf1delete", "laravel-http") -AllowFail | Out-Null
        Run-VBox @("controlvm", $VmName, "natpf1", "laravel-http,tcp,,$HostPort,,$GuestPort") | Out-Null
    } else {
        Run-VBox @("modifyvm", $VmName, "--natpf1", "delete", "laravel-http") -AllowFail | Out-Null
        Run-VBox @("modifyvm", $VmName, "--natpf1", "laravel-http,tcp,,$HostPort,,$GuestPort") | Out-Null

        if (-not $NoStartVm) {
            Write-Host "Starting VM headless..."
            Run-VBox @("startvm", $VmName, "--type", "headless") | Out-Null
        }
    }
}

Write-Host "Starting IP Helper service for portproxy..."
& sc.exe config iphlpsvc start= auto | Out-Null
Start-Service iphlpsvc -ErrorAction SilentlyContinue

& netsh interface portproxy delete v4tov4 listenaddress=0.0.0.0 listenport=$SharePort | Out-Null
& netsh interface portproxy delete v4tov4 listenaddress=192.168.137.1 listenport=$SharePort | Out-Null
& netsh interface portproxy add v4tov4 listenaddress=0.0.0.0 listenport=$SharePort connectaddress=127.0.0.1 connectport=$HostPort | Out-Null

Add-AllowRule -Name "Laravel VM $HostPort" -Port $HostPort
Add-AllowRule -Name "Laravel Hotspot $SharePort" -Port $SharePort

function Test-HttpUrl {
    param([string]$Url)

    try {
        $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 8
        return "OK HTTP $($response.StatusCode)"
    } catch {
        return "FAILED: $($_.Exception.Message)"
    }
}

$hotspotIp = "192.168.137.1"
try {
    $detectedHotspot = Get-NetIPAddress -AddressFamily IPv4 -ErrorAction Stop |
        Where-Object { $_.IPAddress -like "192.168.137.*" -and $_.IPAddress -ne "192.168.137.255" } |
        Select-Object -First 1 -ExpandProperty IPAddress
    if ($detectedHotspot) {
        $hotspotIp = $detectedHotspot
    }
} catch {
    # Keep default Windows Mobile Hotspot IP.
}

$lanIps = @()
try {
    $lanIps = Get-NetIPConfiguration -ErrorAction Stop |
        Where-Object { $_.IPv4DefaultGateway -ne $null -and $_.IPv4Address.IPAddress -notlike "169.254.*" } |
        ForEach-Object { $_.IPv4Address.IPAddress } |
        Sort-Object -Unique
} catch {
    $lanIps = @()
}

Write-Host
Write-Host "Portproxy:"
& netsh interface portproxy show v4tov4

Write-Host
Write-Host "Tests from this Windows host:"
$localUrl = "http://127.0.0.1:$HostPort"
$shareUrl = "http://${hotspotIp}:$SharePort"
Write-Host "$localUrl -> $(Test-HttpUrl $localUrl)"
Write-Host "$shareUrl -> $(Test-HttpUrl $shareUrl)"

Write-Host
Write-Host "Give this URL to devices connected to this Windows Mobile Hotspot:"
Write-Host $shareUrl

if ($lanIps.Count -gt 0) {
    Write-Host
    Write-Host "Optional same-LAN URLs. These only work if the router allows device-to-device traffic:"
    foreach ($ip in $lanIps) {
        Write-Host "http://${ip}:$HostPort"
    }
}

Write-Host
Write-Host "Client test command:"
Write-Host "Test-NetConnection $hotspotIp -Port $SharePort"
