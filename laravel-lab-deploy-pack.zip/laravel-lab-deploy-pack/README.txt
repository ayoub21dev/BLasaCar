Laravel Lab Deploy Pack
=======================

This pack repeats the deployment we did:

Ubuntu VM:
  Nginx -> PHP-FPM -> Laravel in /var/www/lab-laravel

Windows host:
  VirtualBox NAT forwards Windows port 8088 to Ubuntu port 80.
  Windows portproxy shares it to hotspot clients on port 8080.


Step 1 - Install inside Ubuntu
------------------------------

Copy 01-ubuntu-install-laravel-lab.sh into the Ubuntu VM.

In Ubuntu Terminal:

  bash 01-ubuntu-install-laravel-lab.sh

After it finishes, check inside Ubuntu:

  http://localhost


Step 2 - Share from Windows
---------------------------

On the Windows host, run PowerShell as Administrator.

Go to this folder:

  cd C:\tmp\laravel-lab-deploy-pack

Run:

  powershell -ExecutionPolicy Bypass -File .\02-windows-share-virtualbox-laravel.ps1

If the friend has multiple VirtualBox VMs, pass the VM name:

  powershell -ExecutionPolicy Bypass -File .\02-windows-share-virtualbox-laravel.ps1 -VmName "Ubuntu"


Step 3 - Give URL to another device
-----------------------------------

Turn on Windows Mobile Hotspot.
Connect the other phone/laptop to that hotspot.

The script prints a URL like:

  http://192.168.137.1:8080

Open that from the other device.

Use http, not https.


Troubleshooting
---------------

From the other Windows device:

  Test-NetConnection 192.168.137.1 -Port 8080

Good:

  TcpTestSucceeded : True

Bad:

  TcpTestSucceeded : False

If SourceAddress is 192.168.137.1, the test was run on the host computer,
not on the client device.

If ping works but TCP fails, rerun the Windows script as Administrator.

If same Wi-Fi URLs do not work, the router probably blocks device-to-device
traffic. Use Windows Mobile Hotspot instead.
